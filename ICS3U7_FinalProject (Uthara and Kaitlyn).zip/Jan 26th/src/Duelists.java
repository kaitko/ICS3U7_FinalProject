import java.io.*;
import java.awt.* ;
import javax.swing.*;
import java.awt.event.*;
/**
 * @author Uthara and Kaitlyn
 * ICS3U7 Final Assignment
 * Duelists
 * 01/28/2022
 */
public class Duelists extends JFrame implements ActionListener {

	//FOR GRAPHICS:
	JPanel title = new JPanel(new BorderLayout());
	JPanel displayP = new JPanel(new BorderLayout());

	//Gif
	ImageIcon math = new ImageIcon("SwordFight.gif"); 
	JLabel image = new JLabel(math);

	//GUI construction
	JPanel mid = new JPanel();
	JPanel gameSelectionPane = new JPanel();
	JPanel gameArea = new JPanel();
	JPanel menuOptions = new JPanel();
	JButton go = new JButton("Select the Game");
	JButton goHome = new JButton("Return to Main Menu");

	//Game Selection
	String[] games = {"Mapping", "Factor Duel"};
	JLabel lblGame = new JLabel("Game:");
	JComboBox cbxGame= new JComboBox(games);

	//Instructions
	JPanel iPanel = new JPanel();
	JPanel iPanelB = new JPanel();
	JButton instructions = new JButton("Instructions");
	JButton instF = new JButton("Factor Duel");
	JButton instM = new JButton("Mapping");
	JTextArea instructionsTEXT = new JTextArea();
	JTextField inHEADER = new JTextField("Instructions");
	private String fileName = "Instructions.txt";
	String line;
	JButton home = new JButton("Main menu");
	JButton back = new JButton("Return to game");

	//Fonts
	Font instructionsTitle = new Font("RuslanDisplay", Font.BOLD, 30);
	Font instructionsFont = new Font("Times New Roman", Font.PLAIN, 15);
	Font nameF = new Font("Times New Roman", Font.PLAIN, 17);

	/**
	 * Constructor for Duelists class
	 */
	public Duelists() {
		cbxGame.addActionListener(this);
		gameSelectionPane.add(cbxGame); 
		cbxGame.setForeground(Color.black);
		gameSelectionPane.setVisible(true);
		go.addActionListener(this);

		//specified panels for better formatting
		menuOptions.add(lblGame); 
		lblGame.setForeground(Color.white);
		menuOptions.add(gameSelectionPane);
		menuOptions.add(go); 

		//Graphics: Title Page
		title.setPreferredSize(new Dimension(800,500));
		displayP.add(image);

		displayP.setPreferredSize(new Dimension(800,500));
		displayP.setBackground(Color.black); 		
		title.add(displayP, BorderLayout.CENTER); 	
		title.setVisible(true);
		mid.add(title);

		menuOptions.add(instructions);  menuOptions.add(home); 
		menuOptions.add(goHome);        goHome.addActionListener(this);
		goHome.setVisible(false);
		menuOptions.setBackground(Color.BLACK);		
		mid.add(menuOptions, BorderLayout.SOUTH);

		//Instructions:
		instructions.addActionListener(this);
		iPanel.setPreferredSize(new Dimension(750, 600));

		iPanel.setLayout(new BorderLayout());
		iPanel.add(inHEADER, BorderLayout.NORTH); 

		iPanelB.add(home, BorderLayout.EAST);
		iPanelB.add(back, BorderLayout.WEST);
		iPanel.add(instructionsTEXT, BorderLayout.CENTER); 
		iPanel.add(iPanelB, BorderLayout.SOUTH);
		back.addActionListener(this);
		inHEADER.setFont(instructionsTitle);
		inHEADER.setEditable(false);

		home.addActionListener(this); //main menu button

		readInstructions(); //method that reads instructions

		//GUI of instructionsTEXT
		instructionsTEXT.setEditable(false);
		instructionsTEXT.setFont(instructionsFont);
		iPanel.setVisible(false);

		mid.add(iPanel, BorderLayout.CENTER);

		gameArea.setVisible(false);

		mid.add(gameArea);
		mid.setBackground(Color.black); 
		mid.setPreferredSize(new Dimension(800, 625));
		add(mid);
		setResizable(false);

	}//end of constructor

	/**
	 * Read instructions from a text file
	 */
	public void readInstructions() {

		//reading from text file
		try {
			BufferedReader br = new BufferedReader(new FileReader(fileName));
			line = br.readLine();

			while(line !=null) {
				instructionsTEXT.append(line + "\n");
				line = br.readLine();
			}
			br.close();
		}
		catch (IOException e) {
			instructionsTEXT.setText("Uh oh, there's been an error on reading the file!");
		}
	}//end of readInstructions()

	/**
	 * Action event handler
	 */ 
	public void actionPerformed(ActionEvent e){
		if (e.getSource() == go){ //to choose the game
			mid.remove(gameArea); 
			repaint();  
			if (cbxGame.getSelectedIndex() == 0) { 
				gameArea = new MappingPane();
			} else {
				gameArea = new  FactorDuelPane(8, 10, 1, 2);
			}

			goHome.setVisible(true);
			iPanel.setVisible(false);
			title.setVisible(false);
			gameArea.setVisible(true);
			mid.add(gameArea, BorderLayout.SOUTH);
			pack();
		}
		else if (e.getSource() == instructions) { //when instruction button is displayed
			iPanel.setVisible(true);
			title.setVisible(false);
			gameArea.setVisible(false);
			menuOptions.setVisible(false);

		}
		else if (e.getSource() == home) { //when home is button is pressed
			iPanel.setVisible(false);
			gameArea.setVisible(false);
			menuOptions.setVisible(true);
			title.setVisible(true);
		}
		else if (e.getSource() == back) { //when want to return to game after viewing instructions
			iPanel.setVisible(false);
			gameArea.setVisible(true);
			menuOptions.setVisible(true);
			title.setVisible(false);
		}

		else if (e.getSource() == goHome) { //return to MAIN MENU
			iPanel.setVisible(false);
			gameArea.setVisible(false);
			menuOptions.setVisible(true);
			title.setVisible(true);
			goHome.setVisible(false);
		}

	}//end of listener
	
	/**
	 * Main
	 * @param args
	 */
	public static void main ( String[] args ){
		JFrame duelists = new Duelists();
		duelists.setDefaultCloseOperation( EXIT_ON_CLOSE );
		duelists.pack();
		duelists.setLocationRelativeTo(null);
		duelists.setVisible(true);        
	}//end of main
}