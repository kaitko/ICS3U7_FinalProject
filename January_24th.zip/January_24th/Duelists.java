import java.io.*;
import java.awt.* ;
import javax.swing.*;
import java.awt.event.*;

public class Duelists extends JFrame implements ActionListener {

    //FOR GRAPHICS:
    JPanel title = new JPanel(new BorderLayout());
    JPanel displayP = new JPanel(new BorderLayout());
    JButton display = new JButton("Show game");

    //Gif
    ImageIcon math = new ImageIcon(this.getClass().getResource("SwordFight.gif")); 
    JLabel image = new JLabel(math);

    JPanel mid = new JPanel();
    JPanel gameSelectionPane = new JPanel();
    JPanel gameArea = new JPanel();
    JPanel menuOptions = new JPanel();
    JButton go = new JButton("Select the Game");

    //Game Selection
    JButton factorDuel = new JButton("Factor Duel");
    JButton mapping = new JButton("Mapping");
    String[] games = {"Mapping", "Factor Duel"};
    JLabel lblGame = new JLabel("Game:");//also needed to be added on the main page; currently done
    JComboBox cbxGame= new JComboBox(games);
   
    public Duelists() {
        cbxGame.addActionListener(this);
        gameSelectionPane.add(cbxGame); //she added selecting game on to the JPanel called "game selection game"; which is added on to the JPanel mid
        gameSelectionPane.setVisible(true);//
        go.addActionListener(this);
        
        //changed by Uthara to see how it will look; it was originally top.add(stuff); REMOVE THIS COMMENT
        menuOptions.add(lblGame); 
        menuOptions.add(gameSelectionPane);
        menuOptions.add(go);
  
      //Graphics: Title Page
        title.setPreferredSize(new Dimension(800,600));
        displayP.add(image);
        
        displayP.setPreferredSize(new Dimension(600,500));
        displayP.add(display, BorderLayout.SOUTH); //adding the button show game; on SOUTH
        
        displayP.setBackground(Color.black);
        
        title.add(displayP, BorderLayout.CENTER);//change this when you want to adjust the black area
        display.addActionListener(this); //adding listener to show game
        title.setVisible(true);//        
 
        mid.add(title);
        mid.add(menuOptions, BorderLayout.SOUTH); //fix order of buttons showing; IF possible
       

        gameArea.setVisible(false);

        mid.add(gameArea);
        mid.setPreferredSize(new Dimension(800, 650));
        add(mid);
        setResizable(false);

    }
    public void actionPerformed(ActionEvent e){
        if (e.getSource()== go){
            mid.remove(gameArea); repaint(); //required to 
            if (cbxGame.getSelectedIndex()==0) { //this is where you do if clicked on this, or that button
                gameArea = new MappingPane();
            } else {
                gameArea = new  FactorDuelPane(8,10,1, 2);
            }

            gameArea.setVisible(true);
            mid.add(gameArea,BorderLayout.SOUTH);
            pack();
        }
        else if (e.getSource()== display) { //graphics 
        	title.setVisible(false);
            gameArea.setVisible(true);
            
        }
        
    }

    public static void main ( String[] args ){
        JFrame duelists = new Duelists();
        duelists.setDefaultCloseOperation( EXIT_ON_CLOSE );
        duelists.pack();
        duelists.setLocationRelativeTo(null);
        duelists.setVisible( true );        
    }
}
